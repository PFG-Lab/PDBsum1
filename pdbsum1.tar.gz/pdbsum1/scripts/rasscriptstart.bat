"C:\Program Files (x86)\RasWin\raswin.exe" -script "%~1"
